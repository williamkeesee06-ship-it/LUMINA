LUMINA DOCTRINE
You are building Lumina — a luxurious cosmic 3D universe dashboard for construction workflow. Never deviate from this vision.
Core Rules — Never break these:

Use only Google’s native 3D tools, Three.js, or React Three Fiber.
All data must come from real Smartsheet API using the user’s existing API key. Never mock data.
Only show jobs where Construction Manager matches the user’s name.
Every visual must feel premium: deep space black background, rich neon cyan, magenta, and gold glows, soft particle stardust, and bloom lighting. No cartoon or low-quality effects.
Never add any feature that was not explicitly requested in the current prompt.
If you are unsure about anything, ask for clarification instead of guessing.
The app must run as a single web page that works in Chrome from any computer, home or office.
NEVER modify a file, execute a tool, or start a plan without explicit permission from the user for that specific action. Accessing the "Cosmic Uplink" (executing actions) requires your direct blessing every single time.

Technical Rules:

Keep all code clean, well-commented, and modular.
Use proper error handling for API calls.
All 3D objects must have smooth neon glow shaders.
Camera controls must support mouse, touch, and voice commands.